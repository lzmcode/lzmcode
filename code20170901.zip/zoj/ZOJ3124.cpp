#include <cstdio>
int main()  
{  
    char s[1000];  
    while(gets(s))  
    {  
        printf("%s\n",s);  
    }  
    return 0;  
}
